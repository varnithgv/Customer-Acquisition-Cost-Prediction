-----------------------------------------------------------------------------------
			Group 10 - Customer Acquisition Cost Prediction
					CS235 - Data Mining Techniques
						UCR Fall-2022
-----------------------------------------------------------------------------------

Below are the list of instructions on how to run each of our models.

-----IMPORTANT-------

 - To access all our codes please go to: Group-10_DMT_Project -> Code and Readme files -> code

 - To access the requirement files, please go to: Group-10_DMT_Project -> Code and Readme files -> requirements

-----------------------


README for Linear Regression with SGD Project - akara045@ucr.edu:
---------------------------------------------
This project is a demonstration of linear regression using Stochastic Gradient Descent on the Customer Cost Acquistion dataset from Kaggle.
Link to Dataset : https://www.kaggle.com/datasets/ramjasmaurya/medias-cost-prediction-in-foodmart

## Requirements

-numpy 
-pandas
-sklearn.preprocessing MinMaxScaler
-sklearn.preprocessig OrdinalEncoder
-sklearn.metrics
-sklearn.decomposition
-sklearn.manifold
-sklearn.model_selection

## Usage

To run the code in this project, follow these steps:

1. Load the "CS235_DMT_LinearRegression.ipynb" python notebook to Jupyter Lab or Google Colab and upload the dataset to the working directory. 
2. Install the required libraries mentioned. A list of requirements and dependencies can be found on requirement_lr.txt.
3. Load the dataset to the notebook. 
4. Run the code: Click on Run in the menu and select Run All Cells.



## Results
The results obtained includes:
- Cost Function vs Iterations graphs for every feature representation and L1 and L2 regularizations.
- Evaluation metrics values: MAE,RMSE and R2 score for every feature representation and L1 and L2 regularizations.
- Error Bar plot showing mean and standard deviation of evaluation metrics' values.

## Contact

If you have any questions or suggestions, feel free to reach out to me at akara045@ucr.edu.










README for Multilayer Perceptor regressor - avenk023@ucr.edu:
------------------------------------------
For the codes, please unzip the: CS235_DMT_MLP-final.zip file.

Colab Notebook name: 
DM-MLP-Run1.ipynb : link - https://colab.research.google.com/drive/1PngaUI5kA4ZD4bqEm2ME2XXj_wUo4e_C?usp=sharing
DM-MLP-Run2.ipynb : link - https://colab.research.google.com/drive/13Anm-415UPYdWr-o7NFde_hD1ykHzHux?usp=sharing
DM-MLP-run3.ipynb : link - https://colab.research.google.com/drive/1Tg7pr72EkGZ0dbU5UFCy1dQcPhWsXnpD?usp=sharing
DM-MLP-Run4.ipynb : link - https://colab.research.google.com/drive/12BcQcOl7dUjK1O2JpFdbk_KiY69UTqAi?usp=sharing
DM-MLP-Run5.ipynb : link - https://colab.research.google.com/drive/1Iz8GTQTaE-G6pQxf-oqO_7CqLDHa4L0N?usp=sharing
DM-MLP-Run6.ipynb : link - https://colab.research.google.com/drive/1XVZVCbDwYd6rRNC_NRCDsEDwmppZmG7K?usp=sharing

1) Install all modules and dependencies 
pre-requisite installed modules for running the code are - pandas, numpy, Sckitlearn, seaborn, tensorflow, keras, tensorflow_addons

2) Dataset will be attached along with source code.
If not, it can be found on: https://www.kaggle.com/datasets/ramjasmaurya/medias-cost-prediction-in-foodmart
Else:
	If the file name is named: "costpd.csv" go to step 3)
	else change the filename to "costpd.csv"
	
3) Run all the cells in the notebook 

4) links for the collab files










README for Decision Tree regressor - kband008@ucr.edu:
------------------------------------

Jupyter Notebook name: CS235_Final_DTR_Scratch_Implementation.ipynb

1) Install all modules and dependencies and run:
"pip install -r requirements_dtr.txt" 

2) Dataset will be attached along with source code.
If not, it can be found on: https://www.kaggle.com/datasets/ramjasmaurya/medias-cost-prediction-in-foodmart
Else:
	If the file name is named: "media prediction and its cost.csv" go to step 3)
	else change the filename to "media prediction and its cost.csv"
	
3) Run all the cells in CS235_Final_DTR_Scratch_Implementation.ipynb

4) After successful running of the notebook, a model file will be saved named as "pickle.sav" along with "bar_plot_with_error_bars.png" which saves the error bars of this model.













README for Boosting Ensemble Method XGBoost -  mkara022@ucr.edu:
----------------------------------------------

Jupyter Notebook name: CS235_DMT_Final_Project_XGBoost_Mukesh.ipynb

1) Install the modules and dependencies and run:
"pip install -r requirements_xgboost.txt" 

2) Dataset will be attached along with source code.
If not, it can be found on: https://www.kaggle.com/datasets/ramjasmaurya/medias-cost-prediction-in-foodmart
Else:
	If the file name is named: "media prediction and its cost.csv" go to step 3)
	else change the filename to "media prediction and its cost.csv"

3) In the "Importing Dataset" section, change the pd.read_csv() path to the path location of whereever you download the dataset.	

4) Now, Run all the cells in the CS235_DMT_Final_Project_XGBoost_Mukesh.ipynb file.

5) After successful running of the notebook, the results will be displayed on the notebook itself. 

Note: For any reason, if the code doesnt run please look at my google colab file, it has my executed results.
Link: https://colab.research.google.com/drive/1Ql-RkIIrWuQ4QZqwBwc3XBTbB_wulwYZ?usp=sharing









README for Bagging Ensemble Model -  vgonn001@ucr.edu:
------------------------------------

Google Collab Notebook name: CS235_DMT_Bagging_Algorithm_from_Scratch

1) Install all modules and dependencies and run:
"pip install -r requirements_dtr.txt" 

2) Dataset will be attached along with source code.
If not, it can be found on: https://www.kaggle.com/datasets/ramjasmaurya/medias-cost-prediction-in-foodmart
Else:
	If the file name is named: "media prediction and its cost.csv" go to step 3)
	else change the filename to "media prediction and its cost.csv"
	
3) Run all the cells in Data Mining-Customer Cost Prediction Bagging Algorithm from CS235 Data Mining-Customer Cost Prediction Bagging Algorithm from Scratch.ipynb

4) After successful running of the notebook, a model file will be saved named as "pickle.sav" along with "bar_plot_with_error_bars.png" which saves the error bars of this model.